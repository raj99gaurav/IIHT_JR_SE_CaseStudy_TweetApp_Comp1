﻿using Microsoft.EntityFrameworkCore;


namespace TweetAppConsoleApp.Model
{
    public partial class TweetAppContext : DbContext
    {
        public TweetAppContext()
        {
        }

        public TweetAppContext(DbContextOptions<TweetAppContext> options)
            : base(options)
        {
        }
        public virtual DbSet<Registration> Registrations { get; set; }
        public virtual DbSet<Tweet> Tweets { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"Server=(localdb)\mssqllocaldb;Database=TweetApp;User id=raj;Password=raj@123;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Registration>(entity =>
            {
                entity.HasKey(e => e.EmailId)
                    .HasName("PK__Registra__7ED91ACFAB1DE3E5");

                entity.ToTable("Registration");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.Dob)
                    .HasColumnType("datetime")
                    .HasColumnName("DOB");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Passcode)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Tweet>(entity =>
            {
                entity.HasKey(e => e.EmailId)
                    .HasName("PK__Tweet__7ED91ACF382A1937");

                entity.ToTable("Tweet");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.TweetMessage)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TweetTime).HasColumnType("datetime");

                entity.HasOne(d => d.Email)
                    .WithOne(p => p.Tweet)
                    .HasForeignKey<Tweet>(d => d.EmailId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Tweet__EmailId__267ABA7A");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
