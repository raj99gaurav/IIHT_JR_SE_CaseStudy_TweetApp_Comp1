﻿using TweetAppConsoleApp.DataAccessObject;
using TweetAppConsoleApp.Model;
using System;
using System.Globalization;

namespace TweetAppConsoleApp.Services
{
    class UserIntro : IUserIntro
    {
        private readonly IRepository repository;
        private string currentUser;
        public UserIntro(IRepository repo)
        {
            this.repository = repo;
        }
        public void WelcomeScreen()
        {
            Console.WriteLine("WELCOME TO TWEETAPP");
        }
        public void NewUser()

        {
            WelcomeScreen();
            Console.WriteLine(string.Format("{0,-10}\n{1,10}", "1.Create A New Account  ", "2. Login"));
            Console.WriteLine(string.Format("{0,-10}\n{1,10}", "3.Forget Password  ", "4. Rest Password"));
            Console.Write("\nEnter A Number To  Continue (1/2/3/4) : ");
            var response = Console.ReadLine();
            if (response == "1")
            {
                if (Registration())
                {
                    Console.WriteLine("\nRegistration Completed");
                    Dashboard();
                }
                else
                    Console.WriteLine("\nRegistration Failed. Please Try again Later");
            }

            else if (response == "2")
            {
                while (!Login())
                {
                    Console.WriteLine("Unable to Login.Please Check Your Credentials");
                }
                Console.WriteLine("\nLogin Successfull!");
                Dashboard();
            }
            else if (response == "3")
            {
                ForgetPassword();
            }
            else if (response == "4")
                ResetPassword();
            else
                Console.WriteLine("\nInvalid Response");
        }

        public bool Registration()
        {
            WelcomeScreen();
            Console.WriteLine("Please Enter The Below Details");
            Registration registrationData = new Registration();
            var reponse = string.Empty;
            while (reponse == string.Empty)
            {
                Console.Write(string.Format("{0,-10}", "Enter Your First Name : "));
                reponse = Console.ReadLine();
                if (reponse == string.Empty)
                    Console.WriteLine("Please Enter The First Name It is Mandatory");
                else
                    registrationData.FirstName = reponse;
            }

            Console.Write(string.Format("{0,-10}", "Enter Your Last Name : "));
            reponse = Console.ReadLine();
            registrationData.LastName = reponse;

            reponse = string.Empty;
            while (reponse == string.Empty)
            {
                Console.Write(string.Format("{0,-10}", "Enter the Gender : 1-Male  2- Female  3-Others"));

                reponse = Console.ReadLine();
                if (reponse == string.Empty)
                    Console.WriteLine("Please enter the Gender it is Mandatory");
                else
                {
                    switch (reponse)
                    {
                        case "1":
                            registrationData.Gender = "Male";
                            break;
                        case "2":
                            registrationData.Gender = "Female";
                            break;
                        case "3":
                            registrationData.Gender = "Others";
                            break;
                        default:
                            Console.WriteLine("Invalid Response");
                            reponse = string.Empty;
                            break;

                    }
                }
            }

            reponse = string.Empty;
            while (reponse == string.Empty)
            {
                Console.Write(string.Format("{0,-10}", "Please enter your Date Of Birth (dd-MM-yyyy) : "));
                reponse = Console.ReadLine();
                DateTime dateTime = new DateTime(); ;
                bool validDate = DateTime.TryParseExact(reponse, "dd-MM-yyyy", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None, out dateTime);
                if (validDate)
                    registrationData.Dob = dateTime;
                else
                {
                    reponse = string.Empty;
                    Console.WriteLine("Invalid Date format");
                }
            }
            reponse = string.Empty;
            while (reponse == string.Empty)
            {
                Console.Write(string.Format("{0,-10}", "Please enter your Email Id : "));
                reponse = Console.ReadLine();
                if (reponse == string.Empty)
                    Console.WriteLine("Email id is Mandatory");
                else
                {
                    registrationData.EmailId = reponse;
                }
            }
            reponse = string.Empty;
            while (reponse == string.Empty)
            {
                Console.Write(string.Format("{0,-10}", "Please enter your Password : "));
                reponse = Console.ReadLine();
                if (reponse == string.Empty)
                    Console.WriteLine("Password is Mandatory");
                else
                    registrationData.Passcode = reponse;

                reponse = string.Empty;
                Console.Write(string.Format("{0,-10}", "Confirm Password : "));
                reponse = Console.ReadLine();
                if (reponse == string.Empty)
                    Console.WriteLine("Please confirm your password");
                else
                {
                    if (registrationData.Passcode == reponse)
                        Console.WriteLine("Password Matches");
                    else
                    {
                        Console.WriteLine("Password Mismath");
                        reponse = string.Empty;
                    }
                }
            }
            currentUser = registrationData.EmailId;
            return this.repository.Registration(registrationData);
        }


        public bool Login()
        {

            Console.Write("Please enter your Username  :");
            var user = Console.ReadLine();
            Console.Write("\nPlease enter your Password  :");
            var pass = Console.ReadLine();
            currentUser = user;
            return this.repository.Login(user, pass);

        }
        public void Dashboard()
        {
            WelcomeScreen();
            Console.WriteLine(string.Format("{0,-10}|{1,10}|{2,-10}", "1.Post Tweet  ", "2. View All My Tweet", "3. View All Public Tweets"));
            Console.WriteLine(string.Format("{0,-10}|{1,10}", "4.Logout  ", "5. Registration Page"));

            Console.Write("Provide your response (1/2/3/4/5): ");
            var response = Console.ReadLine();
            switch (response)
            {
                case "1":
                    {
                        PostTweet();

                        Dashboard();
                        break;
                    }
                case "2":
                    {
                        GetMyTweets();
                        Console.Write("\nPress any key to go to the dashboard");
                        Dashboard();
                        break;
                    }
                case "3":
                    {
                        GetAllTweets();
                        Console.Write("\nPress any key to go to the dashboard");
                        Dashboard();
                        break;
                    }
                case "4":
                    NewUser();
                    break;
                case "5":
                    Registration();
                    break;
                default:
                    Console.WriteLine("Invalid Input");
                    break;

            }

        }
        public void PostTweet()
        {
            WelcomeScreen();
            Console.WriteLine("Logged in as:  " + currentUser);
            Tweet tweet = new Tweet();
            Console.WriteLine("Tweeting Time");
            Console.Write(string.Format("{1,-10}", "Enter Your Tweet:", ":-"));
            tweet.TweetMessage = Console.ReadLine();
            if (tweet.TweetMessage == string.Empty)
            {
                Console.WriteLine("\n**Empty**");
                PostTweet();
            }

            tweet.TweetTime = DateTime.Now;
            tweet.EmailId = currentUser;
            this.repository.PostTweet(tweet);
            Console.WriteLine("\nTweet Succesfully Posted");
        }
        public void GetMyTweets()
        {
            WelcomeScreen();
            Console.WriteLine("MY TWEETS");
            var tweet = this.repository.GetTweetById(currentUser);
            foreach (Tweet tweets in tweet)
            {
                Console.WriteLine("---------------------------------------------------");
                Console.Write("    Tweet By:" + tweets.EmailId);
                Console.WriteLine("    Tweet At:" + tweets.TweetTime);
                Console.WriteLine("\t" + tweets.TweetMessage);
            }


        }
        public void GetAllTweets()
        {
            WelcomeScreen();
            Console.WriteLine("ALL PUBLIC TWEETS");
            var tweet = this.repository.GetAllTweet();
            foreach (Tweet tweets in tweet)
            {
                Console.WriteLine("---------------------------------------------------");
                Console.Write("    User:" + tweets.EmailId);
                Console.WriteLine("    Tweet At:" + tweets.TweetTime);
                Console.WriteLine("\t" + tweets.TweetMessage);
            }

        }
        public void ForgetPassword()
        {
            WelcomeScreen();
            Console.WriteLine("**FORGET PASSWORD: Use Date of birth info to reset your password**");
            Console.Write("Enter username  :");
            var user = Console.ReadLine();
            Console.Write("\nEnter Registered Date of birth (dd-MM-yyyy)  :");
            var DOB = Console.ReadLine();
            DateTime dateTime = new DateTime();
            bool validDate = DateTime.TryParseExact(DOB, "dd-MM-yyyy", DateTimeFormatInfo.InvariantInfo, DateTimeStyles.None, out dateTime);
            if (validDate)
            {
                Console.Write("\nEnter new Password  :");
                var pass = Console.ReadLine();
                if (this.repository.ForgetPassword(user, dateTime, pass))
                {
                    Console.WriteLine("\nPassword Updated Successfully\n");
                    NewUser();

                }
                else
                {
                    Console.WriteLine("Username or Date of birth Failed to validate!");
                    NewUser();

                }
            }
            else
            {
                Console.WriteLine("Invalid Date format");
                NewUser();
            }

        }
        public void ResetPassword()
        {
            WelcomeScreen();
            Console.WriteLine("RESET PASSWORD \n");
            Console.Write("Please Enter your username  :");
            var user = Console.ReadLine();
            Console.Write("\nPlease Enter your Old passsword  :");
            var oldpass = Console.ReadLine();
            Console.Write("\nPlease Enter your New passsword  :");
            var pass = Console.ReadLine();
            if (this.repository.ResetPassword(user, oldpass, pass))
            {
                Console.WriteLine("\nPassword Reset Successfull*\n");
            }
            else
                Console.WriteLine("\nYour Username or Old Password Failed to validate!");
            NewUser();

        }
    }
}

