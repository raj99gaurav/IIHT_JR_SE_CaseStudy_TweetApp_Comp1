﻿namespace TweetAppConsoleApp.Services
{
    interface IUserIntro
    {
        public void WelcomeScreen();
        public void NewUser();
        public bool Registration();

    }
}
